import csv
from ConstanteSuivre import adjusted_y_values
vec = []
cons = adjusted_y_values

# Read data from the CSV file : https://www.renewables.ninja/
with open('C:/Users/gomez/Downloads/kwhwallon.csv', 'r') as file:
    # Create a CSV reader object
    reader = csv.reader(file, delimiter=',')

    # Skip the header row
    next(reader)

    # Iterate over each row in the CSV file
    for row in reader:
        # Convert the date string to datetime object

        vec.append(float(row[-1]) / 46000.5)

pannel = 0
for i in range(50):
    pannel += 1
    jour = 0  # Initialize variable to store sum during the day
    nuit = 0  # Initialize variable to store sum during the night
    z = 1  # Initialize z variable
    y = 1
    consjour = 0
    consnuit = 0
    for i in range(len(vec)):
        if (i + 1) % 7 == 0:
            z = 0
        if (i + 1) % 22 == 0:
            z = 1
        if z == 0:
            jour += vec[i] * pannel
        if z == 1:
            nuit += vec[i] * pannel

    for i in range(len(cons)):
        if (i + 1) % 7 == 0:
            y = 0
        if (i + 1) % 22 == 0:
            y = 1
        if y == 0:
            consjour += cons[i]
        if y == 1:
            consnuit += cons[i]
    Savingsnuit = -(consnuit - nuit) * 0.25 * 15
    Savingsjour = -(consjour - jour) * 0.25 * 15
    print(jour), print(nuit)

