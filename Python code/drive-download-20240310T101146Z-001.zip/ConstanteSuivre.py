import numpy as np
import matplotlib.pyplot as plt
import test
# Générer une liste de valeurs y (ordonnées)
y_values = test.new_KWH

# Calculer la moyenne des ordonnées de la courbe initiale
mean_y = np.mean(y_values)

# Définir la constante c
c = 2.28 # Exemple de constante, vous pouvez choisir n'importe quelle valeur

# Ajuster chaque valeur de la courbe initiale pour centrer la fonction finale autour de la constante c
adjusted_y_values = [y - (mean_y - c) for y in y_values]

# Générer des valeurs de x (abscisses) correspondant à la taille de la liste y
x_values = np.arange(len(y_values))

# Tracer la fonction d'origine
plt.plot(x_values, np.array(y_values), label='Fonction d\'origine')

# Tracer la fonction centrée autour de la constante c
plt.plot(x_values, adjusted_y_values, label='Fonction centrée autour de c')

# Tracer la constante c
plt.plot(x_values, np.full_like(y_values, c), label='Constante c', linestyle='--')

# Ajouter une ligne horizontale à y = c pour référence
plt.axhline(c, color='black', linewidth=0.5)


plt.xlabel('Index')
plt.ylabel('y')
plt.title('Fonction d\'origine, fonction centrée autour de la constante c et constante c')
plt.legend()
plt.grid(True)
plt.show()
mysumme = 0
for x in adjusted_y_values:
    mysumme += x
print(mysumme)


