import csv

import matplotlib.pyplot as plt

from ConstanteSuivre import adjusted_y_values
vec = []
cons = adjusted_y_values

duree_de_vie = 15
installation = 75
panneaux_solaires = 100
circuit_breaker = 67
entretien = 123
cables = 54
rak = 42
onduleur = [156, 218, 188, 100]
cout_onduleur = onduleur[0]
capacités = [2000, 4000, 8000, 12000]

cout_jour = 0.13
cout_nuit = 0.09
payment_jour = 0.06
payment_nuit = 0.04

épargne_liste = []

# Read data from the CSV file : https://www.renewables.ninja/
with open('C:/Users/gomez/Downloads/kwhwallon.csv', 'r') as file:
    # Create a CSV reader object
    reader = csv.reader(file, delimiter=',')

    # Skip the header row
    next(reader)

    # Iterate over each row in the CSV file
    for row in reader:
        # Convert the date string to datetime object

        vec.append(float(row[-1]) / 46000.5)
pannel = -1
z = 1
for e in range(50):
    pannel += 1
    injday = 0
    injnuit = 0
    retday = 0
    retnuit = 0
    for i in range(len(vec)):
        if (i + 1) % 7 == 0:
            z = 1
        if (i + 1) % 22 == 0:
            z = 0
        if vec[i] * pannel > cons[i] and z == 1:
            injday += vec[i] * pannel - cons[i]
        if vec[i] * pannel > cons[i] and z == 0:
            injnuit += vec[i] * pannel > cons[i]
        if vec[i] * pannel < cons[i] and z == 1:
            retday += cons[i] - vec[i] * pannel
        if vec[i] * pannel < cons[i] and z == 0:
            retnuit += cons[i] - vec[i] * pannel
        if pannel == 0:
            cons_jour_base = retday
            cons_nuit_base = retnuit
    cout_panneaux = pannel * panneaux_solaires
    side_panneaux = pannel * (rak + circuit_breaker + cables)
    for nombre in range(1, 3):
        if pannel * 435 > capacités[nombre]:
            cout_onduleur = onduleur[nombre]
    cout_final = cout_panneaux + side_panneaux + installation + entretien + cout_onduleur
    print(cout_final)
    épargne = duree_de_vie * (-payment_nuit * injnuit + retday * cout_jour +retnuit * cout_nuit - payment_jour * injday - (cons_jour_base * cout_jour + cons_nuit_base * cout_nuit))
    print(épargne)
    épargne_liste.append(épargne)
    payback_period = cout_final / (-épargne/duree_de_vie)
    print(payback_period)



plt.plot(range(len(épargne_liste)), épargne_liste)
plt.xlabel('Nombre de panneaux solaires')
plt.ylabel('Épargne')
plt.title('Épargne en fonction du nombre de panneaux solaires')
plt.grid(True)
plt.show()

